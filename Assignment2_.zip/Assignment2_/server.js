const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const app = express();

app.use(cors());
app.use(express.json());

const PORT = 3001;

app.get('/', (req, res) => {
    res.json({ message: "Welcome to Marketplace." });
});

mongoose.connect('mongodb+srv://zajjhay:Redglass19!@cluster0.vtojkmj.mongodb.net/Marketplace?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    app.listen(PORT, () => {
        console.log('Server running at http://localhost:3001/');
    });
}).catch(err => {
    console.error('Failed to connect to MongoDB:', err);
});

const productController = require('./controllers/productController');

app.post('/products', productController.createProduct);

app.get('/products', productController.getAllProducts);

app.put('/products/:id', productController.updateProduct);

app.delete('/products/:id', productController.deleteProduct);
